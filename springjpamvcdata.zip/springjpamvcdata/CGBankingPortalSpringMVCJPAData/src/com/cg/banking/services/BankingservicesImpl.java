package com.cg.banking.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;

import com.cg.banking.daoservices.AccountDAO;
import com.cg.banking.daoservices.TransactionsDAO;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;

@Component("bankingServices")
public  class BankingservicesImpl implements BankingServices{

	@Autowired
	AccountDAO customerData1 ;
	@Autowired
	TransactionsDAO transactionDAO;

	private final int maxInvalidPinAttempts=3;
	private final static float minBalance=1000;
	
	@Override
	public Account openAccount(String accountType, float initBalance)
			throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException {
		if(initBalance<=minBalance)
			throw new InvalidAmountException("Invalid amount !");
		Account cust = customerData1.save(new Account(accountType,"Active",initBalance));
		transactionDAO.save( new Transaction(initBalance, "Deposit",cust));
		return cust;
	}

	@Override
	public float withdrawAmount(long accountNo, float amount, long pinNumber) throws InsufficientAmountException,
	AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {
		Account customers=null;
		customers=getAccountDetails(accountNo);
		if(customers.getAccountStatus().equalsIgnoreCase("BLOCKED"))
			throw new AccountBlockedException("Account is Blocked!");
		else if(customers.getPinNumber()!=pinNumber)
			throw new InvalidPinNumberException("Wrong Pin Entered!");
		if(customers.getPinAttempts()==maxInvalidPinAttempts) {
			customers.setAccountStatus("Blocked!");
			throw new InvalidPinNumberException();
		} 
		else if(customers.getPinAttempts()>0 && !(customers.getAccountStatus().equalsIgnoreCase("Blocked!")))
			customers.resetPin();
		else if(customers.getAccountBalance()-amount<=minBalance)
			throw new InsufficientAmountException("Amount not present in Account");
		else
			customers.setAccountBalance(customers.getAccountBalance()-amount);
		transactionDAO.save(new Transaction(amount, "Withdraw",customers));
		return customers.getAccountBalance();
	}

	public Account getAccountDetails(long accountNo) throws AccountNotFoundException, BankingServicesDownException {
		//Account customers=null;
		return customerData1.findById(accountNo).orElseThrow
				(()->new AccountNotFoundException("Account Details Not Found For AccountNo"+accountNo));   //Lambda Exp
	}

	public List<Account> getAllAccountDetails() throws BankingServicesDownException {

		List<Account>customers=customerData1.findAll();
		return customers;
	}

	public List<Transaction> getAccountAllTransactions(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException {
		return null;
	}

	public Account accountNo(long accountNo)throws BankingServicesDownException, AccountNotFoundException,AccountBlockedException {
		return customerData1.findById(accountNo).orElseThrow
				(()->new AccountNotFoundException("Account Details Not Found For AccountNo"+accountNo));
	}

	public float depositAmount(long accountNo, float amount)
			throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException {
		Account customers=null;
		customers=getAccountDetails(accountNo);
		if(customers.getAccountStatus().equalsIgnoreCase("BLOCKED!"))
			throw new AccountBlockedException("Account is Blocked!");
		else
			customers.setAccountBalance(customers.getAccountBalance()+amount);
		transactionDAO.save(new Transaction(amount, "Deposit",customers));
		return customers.getAccountBalance() ;
	}

	@Override
	public boolean fundTransfer(long accountNoTo, long accountNoFrom, float transferAmount, long pinNumber)
			throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException,
			BankingServicesDownException, AccountBlockedException {
		Account customerTo=null;
		Account customerFrom=null;
		customerTo=getAccountDetails(accountNoTo);
		customerFrom=getAccountDetails(accountNoFrom);
		if(customerFrom.getAccountBalance()-transferAmount<=minBalance)
			throw new InsufficientAmountException("Amount not present in Account");
		if(customerFrom.getPinNumber()!=pinNumber)
			throw new InvalidPinNumberException("Wrong Pin Entered!");
		else {
			customerFrom.setAccountBalance(withdrawAmount(customerFrom.getAccountNo(),transferAmount,customerFrom.getPinNumber()));
			customerTo.setAccountBalance(depositAmount(customerTo.getAccountNo(),transferAmount));
			return true;
		}
	}
	public List<Transaction> getAccountAllTransaction(long accountNo)
			throws BankingServicesDownException, javax.security.auth.login.AccountNotFoundException {
		return null;
	}

	@Override
	public String accountStatus(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException, AccountBlockedException {
		// TODO Auto-generated method stub
		return null;
	}

}