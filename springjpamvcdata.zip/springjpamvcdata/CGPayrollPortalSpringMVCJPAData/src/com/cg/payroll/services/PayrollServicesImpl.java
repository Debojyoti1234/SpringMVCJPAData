package com.cg.payroll.services;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.exceptions.AssociateDetailsNotfoundException;
@Component("payrollServices")
public class PayrollServicesImpl implements PayrollServices {
	@Autowired
	private AssociateDAO associateDAO;

	@Override
	public Associate acceptAssociateDetails(Associate associate) {
		
		return associateDAO.save(associate);
		
	}

	@Override
	public double calculateNetSalary(int associateId) throws AssociateDetailsNotfoundException {
		Associate associate=getAssociateDetails(associateId);
		double slab1=associate.getSalary().getBasicSalary()-(250000+associate.getYearlyInvestmentUnder8oC()+associate.getSalary().getCompanyPf()+associate.getSalary().getEpf());
		double slab2=slab1-500000;
		double slab3=slab2-1000000;
		double NetSalary;
		if(associate.getSalary().getBasicSalary()<=250000)
		{
			NetSalary=associate.getSalary().getBasicSalary();
		}
		else if(associate.getSalary().getBasicSalary()>250000 && associate.getSalary().getBasicSalary()<=500000) {
			NetSalary=associate.getSalary().getBasicSalary()-(slab1*0.1);
		}
		else if(associate.getSalary().getBasicSalary()>500000 && associate.getSalary().getBasicSalary()<=1000000) {
			NetSalary=associate.getSalary().getBasicSalary()-((slab1*0.1)+slab2*0.2);
		}
		else {
			NetSalary=associate.getSalary().getBasicSalary()-((slab1*0.1)+(slab2*0.2)+(slab3*0.3));
		}
		return NetSalary;
	}
	@Override
	public Associate getAssociateDetails(int associateId) throws AssociateDetailsNotfoundException {
		return associateDAO.findById(associateId).orElseThrow(()->new AssociateDetailsNotfoundException("Associate Details not found"+associateId));

	}
	public List<Associate> getAllAssociateDetails() {

		return associateDAO.findAll();
	}
	public int acceptAssociateDetails(String firstName, String lastName, String emailId, String department,
			String designation, int pancard, int yearlyInvestmentUnder80C, int basicSalary, int epf, int companyPf,
			int accountNumber, String bankName, int ifscCode) {
		return 0;
	}
	public List<Associate> getAllAssociatesDetails() {
		return null;
	}

	
}
